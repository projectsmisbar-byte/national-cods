#!/usr/bin/env python3
"""
الآلة الصامتة — مترجم الآلة الافتراضية
الاستخدام: python3 machine.py program.bin <input>
"""
import sys

OPCODES = {
    0x01: 'PUSH_K',
    0x02: 'LOAD_I',
    0x03: 'XOR',
    0x04: 'ADD',
    0x05: 'CHECK',
    0x06: 'AND',
    0x07: 'JNZ',
    0x08: 'PRINT_FLAG',
    0x09: 'PRINT_FAIL',
    0x0A: 'HALT',
}

FLAG_ENCRYPTED = bytes([
0x53, 0x41, 0x7b, 0x76, 0x6d, 0x5f, 0x30, 0x70, 0x63, 0x30, 0x64, 0x33, 0x5f, 0x72, 0x33, 0x76, 0x5f, 0x31, 0x34, 0x34, 0x36, 0x7d
])

def run(bytecode, user_input):
    stack = []
    ip = 0
    inp = user_input.encode('utf-8') if isinstance(user_input, str) else user_input

    while ip < len(bytecode):
        op = bytecode[ip]; ip += 1

        if op == 0x01:   # PUSH_K
            val = bytecode[ip]; ip += 1
            stack.append(val)
        elif op == 0x02: # LOAD_I
            idx = bytecode[ip]; ip += 1
            stack.append(inp[idx] if idx < len(inp) else 0)
        elif op == 0x03: # XOR
            b = stack.pop(); a = stack.pop()
            stack.append(a ^ b)
        elif op == 0x04: # ADD
            b = stack.pop(); a = stack.pop()
            stack.append((a + b) % 256)
        elif op == 0x05: # CHECK
            expected = stack.pop(); got = stack.pop()
            stack.append(1 if got == expected else 0)
        elif op == 0x06: # AND
            b = stack.pop(); a = stack.pop()
            stack.append(a & b)
        elif op == 0x07: # JNZ
            offset = bytecode[ip]; ip += 1
            val = stack.pop()
            if val != 0:
                ip += offset
        elif op == 0x08: # PRINT_FLAG
            print("[+] Access Granted!")
            print(user_input)
        elif op == 0x09: # PRINT_FAIL
            print("[-] Wrong password. Access Denied.")
        elif op == 0x0A: # HALT
            break

if __name__ == '__main__':
    if len(sys.argv) < 3:
        print(f"Usage: python3 machine.py program.bin <password>")
        sys.exit(1)
    code = open(sys.argv[1], 'rb').read()
    run(code, sys.argv[2])
